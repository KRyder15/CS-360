package com.example.inventorytracker;

import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class SmsUtils {
    public static final int REQ_SMS = 1010;

    public static boolean ensurePermission(AppCompatActivity act){
        if (ActivityCompat.checkSelfPermission(act, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(act, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
            return false;
        }
        return true;
    }

    public static void trySendLowStock(AppCompatActivity act, String phone, String message){
        if (ActivityCompat.checkSelfPermission(act, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED){
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
        }
        // If not granted, skip silently (app continues to function).
    }
}
