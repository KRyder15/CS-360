package com.example.inventorytracker;

import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper db;
    private ItemAdapter adapter;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);

        EditText etName = findViewById(R.id.etName);
        EditText etQty  = findViewById(R.id.etQty);
        Button btnAdd   = findViewById(R.id.btnAdd);

        RecyclerView rv = findViewById(R.id.recycler);
        rv.setLayoutManager(new androidx.recyclerview.widget.GridLayoutManager(this, 2));
        adapter = new ItemAdapter(new ItemAdapter.OnAction() {
            @Override public void onUpdateQty(Item it, int newQty) {
                db.updateQty(it.id, newQty);
                refresh();
                if (newQty < 5) {
                    if (SmsUtils.ensurePermission(MainActivity.this)) {
                        SmsUtils.trySendLowStock(MainActivity.this, "5551234567",
                                "Low stock alert: " + it.name + " qty=" + newQty);
                    }
                }
            }
            @Override public void onDelete(Item it) { db.deleteItem(it.id); refresh(); }
        });
        rv.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String qStr = etQty.getText().toString().trim();
            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qStr)) {
                Toast.makeText(this, "Enter name and qty", Toast.LENGTH_SHORT).show();
                return;
            }
            int q = Integer.parseInt(qStr);
            db.addItem(name, q);
            etName.setText(""); etQty.setText("");
            refresh();
        });

        refresh();
    }

    private void refresh() {
        Cursor c = db.getAllItems();
        adapter.setFromCursor(c);
        if (c != null) c.close();
    }
}
