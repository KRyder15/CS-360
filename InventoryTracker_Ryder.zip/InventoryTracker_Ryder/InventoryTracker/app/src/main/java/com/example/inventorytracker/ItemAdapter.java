package com.example.inventorytracker;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
    interface OnAction { void onUpdateQty(Item item, int newQty); void onDelete(Item item); }
    private final List<Item> data = new ArrayList<>();
    private final OnAction callbacks;

    public ItemAdapter(OnAction cb){ this.callbacks = cb; }

    public void setFromCursor(Cursor c){
        data.clear();
        if (c != null && c.moveToFirst()){
            int iId=c.getColumnIndexOrThrow("id");
            int iName=c.getColumnIndexOrThrow("name");
            int iQty=c.getColumnIndexOrThrow("qty");
            do { data.add(new Item(c.getLong(iId), c.getString(iName), c.getInt(iQty))); } while(c.moveToNext());
        }
        notifyDataSetChanged();
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int vt) {
        View v = LayoutInflater.from(p.getContext()).inflate(R.layout.row_item, p, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos) {
        Item it = data.get(pos);
        h.name.setText(it.name);
        h.qty.setText(String.valueOf(it.qty));
        h.btnInc.setOnClickListener(v -> callbacks.onUpdateQty(it, it.qty + 1));
        h.btnDec.setOnClickListener(v -> callbacks.onUpdateQty(it, Math.max(0, it.qty - 1)));
        h.btnDel.setOnClickListener(v -> callbacks.onDelete(it));
    }

    @Override public int getItemCount(){ return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, qty; ImageButton btnInc, btnDec, btnDel;
        VH(View v){ super(v);
            name=v.findViewById(R.id.tvName); qty=v.findViewById(R.id.tvQty);
            btnInc=v.findViewById(R.id.btnInc); btnDec=v.findViewById(R.id.btnDec); btnDel=v.findViewById(R.id.btnDel);
        }
    }
}
