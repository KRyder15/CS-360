package com.example.inventorytracker;

public class Item {
    public long id; public String name; public int qty;
    public Item(long id, String name, int qty) { this.id=id; this.name=name; this.qty=qty; }
}
