package com.example.inventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "inventory.db";
    private static final int DB_VERSION = 1;

    public static final String T_USERS = "users";
    public static final String T_INV = "inventory";

    public DatabaseHelper(Context ctx) { super(ctx, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "username TEXT UNIQUE NOT NULL," +
                "password TEXT NOT NULL)");

        db.execSQL("CREATE TABLE " + T_INV + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT NOT NULL," +
                "qty INTEGER NOT NULL DEFAULT 0," +
                "created_at INTEGER NOT NULL)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_INV);
        onCreate(db);
    }

    // --- Users ---
    public boolean createUser(String u, String p) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", u); cv.put("password", p);
        long id = db.insert(T_USERS, null, cv);
        return id != -1;
    }

    public boolean validateUser(String u, String p) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT id FROM " + T_USERS + " WHERE username=? AND password=?", new String[]{u, p});
        boolean ok = c.moveToFirst();
        c.close();
        return ok;
    }

    // --- Inventory CRUD ---
    public long addItem(String name, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name); cv.put("qty", qty); cv.put("created_at", System.currentTimeMillis());
        return db.insert(T_INV, null, cv);
    }

    public int updateQty(long id, int qty) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("qty", qty);
        return db.update(T_INV, cv, "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(T_INV, "id=?", new String[]{String.valueOf(id)});
    }

    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery("SELECT id, name, qty, created_at FROM " + T_INV + " ORDER BY created_at DESC", null);
    }
}
